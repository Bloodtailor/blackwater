// Analytic signed distance field of the passable cave volume, derived from
// the graph (data.ts). Convention: d < 0 inside water/passable space, d > 0
// inside rock. The SAME field drives mesh generation (mesh.ts) and collision
// (main), so the two can never disagree. Three-free: testable in node.
//
// Shape language (M2.5, user feedback): chambers are ELLIPSOIDS (per-axis
// stretch), big rooms get large-scale wall warp so nothing reads as a sphere,
// rooms can contain solid rock PILLARS, and door plugs are flat DISCS aligned
// to the tunnel so they never bulge into neighboring passages.

import { EDGES, getNode, NODES, SKY_SHAFT, type CaveEdge, type Zone } from './data';
import { fbm } from '../util/noise';
import { TUNING } from '../tuning';

export interface PrimRegion {
  zone: Zone;
  width: 'chamber' | 'open' | 'normal' | 'squeeze';
  ref: string;
}

interface Prim extends PrimRegion {
  ax: number; ay: number; az: number;
  bx: number; by: number; bz: number;
  r: number; // capsule radius at the a end / nominal radius (chambers)
  rb: number; // capsule radius at the b end (≠ r → tapered cone: stalactites)
  rx: number; ry: number; rz: number; // ellipsoid radii (chambers)
  ellipsoid: boolean;
  solid: boolean; // pillars, spikes: subtract from passable space
  broad: number; // large-scale wall-warp amplitude (big chambers)
  /** Flat floor: soft-intersect the chamber with the half-space on the
   *  positive side of plane dot(N,p) = D. N is world-up normally, or the
   *  room's deceptive falseUp (user 2026-07-19: the Listing Room). */
  floorN?: [number, number, number];
  floorD?: number;
  noiseAmp: number;
}

export interface DoorBlock {
  id: string;
  c: [number, number, number];
  axis: [number, number, number];
  r: number;
  halfLen: number;
}

const G = TUNING.geometry;
const BIG = 8;
const HASH_CELL = 4;

let prims: Prim[] = [];
let hash = new Map<number, number[]>();
let doorBlocks: DoorBlock[] = [];
export let bounds = { min: [0, 0, 0] as [number, number, number], max: [0, 0, 0] as [number, number, number] };

function widthRadius(w: CaveEdge['width']): number {
  return w === 'open' ? G.radiusOpen : w === 'squeeze' ? G.radiusSqueeze : G.radiusNormal;
}

function noiseAmpFor(r: number): number {
  return Math.min(Math.max(r * G.noiseAmpFactor, 0.12), G.noiseAmpMax);
}

function hashKey(ix: number, iy: number, iz: number): number {
  return (ix + 128) + (iy + 128) * 512 + (iz + 128) * 262144;
}

function segPrim(base: Omit<Prim, 'rb' | 'rx' | 'ry' | 'rz' | 'ellipsoid' | 'solid' | 'broad'> & { rb?: number }, solid = false): Prim {
  return { ...base, rb: base.rb ?? base.r, rx: base.r, ry: base.r, rz: base.r, ellipsoid: false, solid, broad: 0 };
}

// Polynomial smooth max — soft intersection (curved, soft floor edges).
function smax(a: number, b: number, k: number): number {
  const h = Math.max(k - Math.abs(a - b), 0) / k;
  return Math.max(a, b) + h * h * k * 0.25;
}

export function initSdf(): void {
  prims = [];

  // Edge polylines first: pillars must keep guaranteed clearance from every
  // authored path (a pillar in a tunnel mouth is a softlock; the swim/pathing
  // systems assume polylines are swimmable).
  const pathSamples: [number, number, number][] = [];
  for (const e of EDGES) {
    const pts: [number, number, number][] = [getNode(e.a).pos, ...(e.waypoints ?? []), getNode(e.b).pos];
    for (let i = 1; i < pts.length; i++) {
      const [ax, ay, az] = pts[i - 1];
      const [bx, by, bz] = pts[i];
      const steps = Math.max(2, Math.ceil(Math.hypot(bx - ax, by - ay, bz - az)));
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        pathSamples.push([ax + (bx - ax) * t, ay + (by - ay) * t, az + (bz - az) * t]);
      }
    }
  }
  const horizClearanceTo = (px: number, pz: number, yLo: number, yHi: number): number => {
    let best = Infinity;
    for (const [sx, sy, sz] of pathSamples) {
      if (sy < yLo - 2 || sy > yHi + 2) continue;
      const d = Math.hypot(sx - px, sz - pz);
      if (d < best) best = d;
    }
    return best;
  };

  for (const n of NODES) {
    if (n.kind === 'audio') continue; // pure sound emitters carve nothing
    const s = n.stretch ?? [1, 1, 1];
    const rx = n.radius * s[0];
    const ry = n.radius * s[1];
    const rz = n.radius * s[2];
    const maxR = Math.max(rx, ry, rz);
    // room "up": world up, or the deceptive falseUp (the Listing Room)
    const up: [number, number, number] = n.falseUp ?? [0, 1, 0];
    let floorN: [number, number, number] | undefined;
    let floorD: number | undefined;
    if (n.floor !== undefined) {
      floorN = up;
      const px = n.pos[0] - up[0] * ry * n.floor;
      const py = n.pos[1] - up[1] * ry * n.floor;
      const pz = n.pos[2] - up[2] * ry * n.floor;
      floorD = up[0] * px + up[1] * py + up[2] * pz;
    }
    prims.push({
      ax: n.pos[0], ay: n.pos[1], az: n.pos[2],
      bx: n.pos[0], by: n.pos[1], bz: n.pos[2],
      r: n.radius, rb: n.radius, rx, ry, rz,
      ellipsoid: true,
      solid: false,
      broad: n.radius >= 4 ? Math.min(maxR * 0.15, 3.5) : 0,
      floorN,
      floorD,
      noiseAmp: noiseAmpFor(Math.min(rx, ry, rz)),
      zone: n.zone, width: 'chamber', ref: n.id,
    });
    // Stalactites & stalagmites (user 2026-07-18): tapered solid spikes in air
    // rooms, grown along the room's up (falseUp in deception rooms — they lie
    // WITH the architecture); kept clear of every authored path like pillars.
    if (n.spikes) {
      // basis perpendicular to `up`
      const t1: [number, number, number] =
        Math.abs(up[1]) < 0.95
          ? [up[2] === 0 && up[0] === 0 ? 1 : -up[2], 0, up[0]]
          : [1, 0, 0];
      const l1 = Math.hypot(...t1) || 1;
      t1[0] /= l1; t1[1] /= l1; t1[2] /= l1;
      const t2: [number, number, number] = [
        up[1] * t1[2] - up[2] * t1[1],
        up[2] * t1[0] - up[0] * t1[2],
        up[0] * t1[1] - up[1] * t1[0],
      ];
      for (let i = 0; i < n.spikes; i++) {
        const ang = i * 2.399 + n.pos[2] * 0.31;
        const rr = 0.15 + 0.6 * Math.abs(Math.sin(i * 12.99 + n.pos[0]));
        const a = Math.cos(ang) * rx * rr;
        const b = Math.sin(ang) * rz * rr;
        const px = n.pos[0] + t1[0] * a + t2[0] * b;
        const py = n.pos[1] + t1[1] * a + t2[1] * b;
        const pz = n.pos[2] + t1[2] * a + t2[2] * b;
        const frac = (a / rx) ** 2 + (b / rz) ** 2;
        if (frac > 0.72) continue;
        if (horizClearanceTo(px, pz, n.pos[1] - ry, n.pos[1] + ry) < 1.0) continue;
        const vary = Math.abs(Math.sin(i * 3.37 + n.pos[2]));
        const reach = ry * Math.sqrt(1 - frac);
        if (i % 2 === 0) {
          const len = 0.7 + 1.2 * vary;
          prims.push(segPrim({
            ax: px + up[0] * (reach + 0.8), ay: py + up[1] * (reach + 0.8), az: pz + up[2] * (reach + 0.8),
            bx: px + up[0] * (reach - len), by: py + up[1] * (reach - len), bz: pz + up[2] * (reach - len),
            r: 0.42, rb: 0.12, noiseAmp: 0.1, zone: n.zone, width: 'chamber', ref: `${n.id}-tite${i}`,
          }, true));
        } else if (floorD !== undefined) {
          // project the offset point onto the floor plane, grow along up
          const over = up[0] * px + up[1] * py + up[2] * pz - floorD;
          const fx = px - up[0] * over, fy = py - up[1] * over, fz = pz - up[2] * over;
          const len = 0.4 + 0.7 * vary;
          prims.push(segPrim({
            ax: fx - up[0] * 0.6, ay: fy - up[1] * 0.6, az: fz - up[2] * 0.6,
            bx: fx + up[0] * len, by: fy + up[1] * len, bz: fz + up[2] * len,
            r: 0.5, rb: 0.14, noiseAmp: 0.1, zone: n.zone, width: 'chamber', ref: `${n.id}-mite${i}`,
          }, true));
        }
      }
    }
    // pillars: deterministic solid columns, mid-band of the room only, shrunk
    // or skipped so they always clear every authored path by ≥1.1 m.
    if (n.pillars) {
      const yLo = n.pos[1] - ry;
      const yHi = n.pos[1] + ry;
      for (let i = 0; i < n.pillars; i++) {
        const ang = i * 2.399 + n.pos[0] * 0.7 + n.pos[2] * 0.3;
        const rr = 0.3 + 0.3 * Math.abs(Math.sin(i * 5.7 + n.pos[1]));
        const px = n.pos[0] + Math.cos(ang) * rx * rr;
        const pz = n.pos[2] + Math.sin(ang) * rz * rr;
        const want = 0.7 + 0.7 * Math.abs(Math.sin(i * 3.1 + n.pos[2]));
        const pr = Math.min(want, horizClearanceTo(px, pz, yLo, yHi) - 1.1);
        if (pr < 0.4) continue;
        prims.push(segPrim({
          ax: px, ay: n.pos[1] - ry * 0.95, az: pz,
          bx: px, by: n.pos[1] + ry * 0.95, bz: pz,
          r: pr, noiseAmp: 0.3, zone: n.zone, width: 'chamber', ref: `${n.id}-pillar${i}`,
        }, true));
      }
    }
  }
  // (M4.5: dry-pocket benches removed — flat floors via `floor` replace them.)

  prims.push(segPrim({
    ax: SKY_SHAFT.a[0], ay: SKY_SHAFT.a[1], az: SKY_SHAFT.a[2],
    bx: SKY_SHAFT.b[0], by: SKY_SHAFT.b[1], bz: SKY_SHAFT.b[2],
    r: SKY_SHAFT.r, noiseAmp: noiseAmpFor(SKY_SHAFT.r), zone: 'sinkhole', width: 'chamber', ref: 'sky-shaft',
  }));
  for (const e of EDGES) {
    const pts: [number, number, number][] = [getNode(e.a).pos, ...(e.waypoints ?? []), getNode(e.b).pos];
    const r = widthRadius(e.width);
    for (let i = 1; i < pts.length; i++) {
      prims.push(segPrim({
        ax: pts[i - 1][0], ay: pts[i - 1][1], az: pts[i - 1][2],
        bx: pts[i][0], by: pts[i][1], bz: pts[i][2],
        r, noiseAmp: noiseAmpFor(r), zone: getNode(e.a).zone, width: e.width, ref: `${e.a}~${e.b}`,
      }));
    }
  }
  // spatial hash + world bounds
  hash = new Map();
  const mn: [number, number, number] = [Infinity, Infinity, Infinity];
  const mx: [number, number, number] = [-Infinity, -Infinity, -Infinity];
  prims.forEach((p, idx) => {
    const maxR = Math.max(p.rx, p.ry, p.rz);
    const pad = maxR + p.broad + G.noiseAmpMax + 1.2;
    const lo = [Math.min(p.ax, p.bx) - pad, Math.min(p.ay, p.by) - pad, Math.min(p.az, p.bz) - pad];
    const hi = [Math.max(p.ax, p.bx) + pad, Math.max(p.ay, p.by) + pad, Math.max(p.az, p.bz) + pad];
    if (!p.solid) {
      for (let a = 0; a < 3; a++) {
        mn[a] = Math.min(mn[a], lo[a]);
        mx[a] = Math.max(mx[a], hi[a]);
      }
    }
    for (let ix = Math.floor(lo[0] / HASH_CELL); ix <= Math.floor(hi[0] / HASH_CELL); ix++)
      for (let iy = Math.floor(lo[1] / HASH_CELL); iy <= Math.floor(hi[1] / HASH_CELL); iy++)
        for (let iz = Math.floor(lo[2] / HASH_CELL); iz <= Math.floor(hi[2] / HASH_CELL); iz++) {
          const key = hashKey(ix, iy, iz);
          const list = hash.get(key);
          if (list) list.push(idx);
          else hash.set(key, [idx]);
        }
  });
  bounds = { min: mn, max: mx };
}

export function setDoorBlocks(blocks: DoorBlock[]): void {
  doorBlocks = blocks;
}

export function getDoorBlocks(): DoorBlock[] {
  return doorBlocks;
}

// Signed distance to a capsule with linearly tapered radius (r at a → rb at
// b) — constant-radius capsules when r === rb, round cones for spikes.
function capsuleDist(px: number, py: number, pz: number, p: Prim): number {
  const abx = p.bx - p.ax, aby = p.by - p.ay, abz = p.bz - p.az;
  const apx = px - p.ax, apy = py - p.ay, apz = pz - p.az;
  const len2 = abx * abx + aby * aby + abz * abz;
  let t = len2 > 0 ? (apx * abx + apy * aby + apz * abz) / len2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  const dx = apx - abx * t, dy = apy - aby * t, dz = apz - abz * t;
  return Math.sqrt(dx * dx + dy * dy + dz * dz) - (p.r + (p.rb - p.r) * t);
}

// Ellipsoid SDF approximation (good near the surface, exact at center line).
function ellipsoidDist(px: number, py: number, pz: number, p: Prim): number {
  const dx = px - p.ax, dy = py - p.ay, dz = pz - p.az;
  const k0 = Math.sqrt((dx / p.rx) ** 2 + (dy / p.ry) ** 2 + (dz / p.rz) ** 2);
  if (k0 < 1e-4) return -Math.min(p.rx, p.ry, p.rz);
  const k1 = Math.sqrt((dx / (p.rx * p.rx)) ** 2 + (dy / (p.ry * p.ry)) ** 2 + (dz / (p.rz * p.rz)) ** 2);
  return (k0 * (k0 - 1)) / k1;
}

// Core field. withDoors: closed doors add flat disc plugs (CSG subtract).
export function sdf(x: number, y: number, z: number, withDoors = true): number {
  const list = hash.get(hashKey(Math.floor(x / HASH_CELL), Math.floor(y / HASH_CELL), Math.floor(z / HASH_CELL)));
  let d = BIG;
  if (list) {
    const noise = fbm(x * G.noiseFreq, y * G.noiseFreq, z * G.noiseFreq);
    let broadNoise: number | null = null;
    // pass 1: union of passable space
    for (const idx of list) {
      const p = prims[idx];
      if (p.solid) continue;
      const base = p.ellipsoid ? ellipsoidDist(x, y, z, p) : capsuleDist(x, y, z, p);
      let di = base - noise * p.noiseAmp;
      if (p.broad > 0) {
        if (broadNoise === null) broadNoise = fbm(x * 0.06 + 31.7, y * 0.06, z * 0.06, 2);
        di -= broadNoise * p.broad;
      }
      // flat floor: soft intersection with the half-space above the floor
      // plane — mostly level, a quarter of the wall noise, soft edges
      if (p.floorN !== undefined && p.floorD !== undefined) {
        const along = p.floorN[0] * x + p.floorN[1] * y + p.floorN[2] * z;
        di = smax(di, p.floorD - along - noise * p.noiseAmp * 0.25, 1.2);
      }
      if (di < d) d = di;
    }
    // pass 2: subtract solids (pillars, stalactites/stalagmites)
    for (const idx of list) {
      const p = prims[idx];
      if (!p.solid) continue;
      const base = p.ellipsoid ? ellipsoidDist(x, y, z, p) : capsuleDist(x, y, z, p);
      const ds = base - noise * p.noiseAmp;
      if (-ds > d) d = -ds;
    }
  }
  if (withDoors) {
    for (const b of doorBlocks) {
      const rx = x - b.c[0], ry = y - b.c[1], rz = z - b.c[2];
      const axial = rx * b.axis[0] + ry * b.axis[1] + rz * b.axis[2];
      const ox = rx - axial * b.axis[0], oy = ry - axial * b.axis[1], oz = rz - axial * b.axis[2];
      const radial = Math.sqrt(ox * ox + oy * oy + oz * oz);
      const dd = Math.max(Math.abs(axial) - b.halfLen, radial - b.r);
      if (-dd > d) d = -dd;
    }
  }
  return d;
}

export function regionAt(x: number, y: number, z: number): PrimRegion | null {
  const list = hash.get(hashKey(Math.floor(x / HASH_CELL), Math.floor(y / HASH_CELL), Math.floor(z / HASH_CELL)));
  if (!list || list.length === 0) return null;
  let best = Infinity;
  let bestPrim: Prim | null = null;
  for (const idx of list) {
    const p = prims[idx];
    if (p.solid) continue;
    const di = p.ellipsoid ? ellipsoidDist(x, y, z, p) : capsuleDist(x, y, z, p);
    if (di < best) {
      best = di;
      bestPrim = p;
    }
  }
  return bestPrim ? { zone: bestPrim.zone, width: bestPrim.width, ref: bestPrim.ref } : null;
}

const EPS = 0.15;
export function gradient(x: number, y: number, z: number, out: [number, number, number]): void {
  out[0] = sdf(x + EPS, y, z) - sdf(x - EPS, y, z);
  out[1] = sdf(x, y + EPS, z) - sdf(x, y - EPS, z);
  out[2] = sdf(x, y, z + EPS) - sdf(x, y, z - EPS);
  const len = Math.hypot(out[0], out[1], out[2]) || 1;
  out[0] /= len;
  out[1] /= len;
  out[2] /= len;
}

// Push a point back inside passable space with `clearance` from the wall.
// Returns true if a correction was applied.
export function resolveCollision(pos: { x: number; y: number; z: number }, clearance: number): boolean {
  let corrected = false;
  const g: [number, number, number] = [0, 0, 0];
  for (let i = 0; i < 3; i++) {
    const d = sdf(pos.x, pos.y, pos.z);
    if (d <= -clearance) break;
    gradient(pos.x, pos.y, pos.z, g);
    const push = d + clearance + 0.01;
    pos.x -= g[0] * push;
    pos.y -= g[1] * push;
    pos.z -= g[2] * push;
    corrected = true;
  }
  return corrected;
}
